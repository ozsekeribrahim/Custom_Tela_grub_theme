# Custom_Tela_grubthem
Grub theme costumization from tela. For dual boot (ubuntu and windows)
